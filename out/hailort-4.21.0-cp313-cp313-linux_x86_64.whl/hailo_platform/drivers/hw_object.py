from hailo_platform.pyhailort.hw_object import * # noqa F401
